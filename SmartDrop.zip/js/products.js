const products = [
  {
    id: 1,
    title: "iPhone 13",
    price: "13 500 грн",
    image: "iphone13.jpg",
    description: "Стан 9/10 <br> Акумулятор 90% <br> Повний комплект (Телефон, зарядний блок та 3 чохли в подарунок)"
  },

  {
    id: 2,
    title: "Nike Air Force",
    price: "1500 грн",
    image: "nike.jpg",
    description: "Оригінал <br> Розмір 44.5"
  },

  {
    id: 3,
    title: "PlayStation 5",
    price: "20 700 грн",
    image: "ps5.jpg",
    description: "Ідеальний стан <br> Без дефектів"
  },

  {
    id: 4,
    title: "AirPods Pro 2",
    price: "4 800 грн",
    image: "airpods.jpg",
    description: "Оригінал <br> Чистий звук <br> Комплект з чохлом"
  },

  {
    id: 5,
    title: "Apple Watch Series 7",
    price: "6 200 грн",
    image: "watch.jpg",
    description: "Стан 9/10 <br> Акумулятор тримає добре <br> Без дефектів"
  },

  {
    id: 6,
    title: "Xbox Series S",
    price: "9 900 грн",
    image: "xbox.jpg",
    description: "Ідеальний стан <br> 512 GB <br> Комплект з геймпадом"
  },

  {
    id: 7,
    title: "Samsung Galaxy S22",
    price: "11 800 грн",
    image: "samsung.jpg",
    description: "Стан 9/10 <br> 128 GB <br> Повний комплект"
  },

  {
    id: 8,
    title: "JBL Charge 5",
    price: "3 200 грн",
    image: "jbl.jpg",
    description: "Оригінал <br> Потужний звук <br> Тримає заряд добре"
  }
];
